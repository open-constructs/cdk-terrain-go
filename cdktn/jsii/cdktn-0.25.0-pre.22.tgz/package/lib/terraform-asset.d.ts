import { Construct } from "constructs";
import { AssetHashType, IAsset } from "./assets";
export interface TerraformAssetConfig {
    readonly path: string;
    readonly type?: AssetType;
    readonly assetHash?: string;
    /**
     * How the `assetHash` is derived.
     *
     * `SOURCE` (the default) hashes the source path. `CUSTOM` uses the
     * `assetHash` value verbatim and requires it to be set. `OUTPUT` is not
     * supported yet — there is no bundling step to produce an output to hash —
     * and throws if requested.
     *
     * If `assetHash` is set, this must be `undefined` or `AssetHashType.CUSTOM`.
     *
     * @default AssetHashType.SOURCE
     */
    readonly assetHashType?: AssetHashType;
}
export declare enum AssetType {
    FILE = 0,
    DIRECTORY = 1,
    ARCHIVE = 2
}
export declare class TerraformAsset extends Construct implements IAsset {
    private stack;
    private sourcePath;
    readonly assetHash: string;
    type: AssetType;
    /**
     * A Terraform Asset takes a file or directory outside of the CDK Terrain context and moves it into it.
     * Assets copy referenced files into the stacks context for further usage in other resources.
     * @param scope
     * @param id
     * @param config
     */
    constructor(scope: Construct, id: string, config: TerraformAssetConfig);
    /**
     * Resolve the asset hash from `assetHash` and `assetHashType`.
     *
     * Honors the same contract `AssetOptions` documents: an explicit
     * `assetHash` means the type is `CUSTOM`, `CUSTOM` requires a hash, and
     * `OUTPUT` is rejected because there is no bundling step to hash yet.
     * `SOURCE` (the default) hashes the source path as before.
     * @param id - construct id, for error messages
     * @param config - the asset configuration
     */
    private resolveAssetHash;
    private get namedFolder();
    /**
     * How this asset is written to disk. The layout (directory vs single file)
     * and the artifact name are derived from this rather than from `type`
     * directly, so the two never disagree.
     */
    private get packaging();
    /**
     * The path relative to the root of the terraform directory in posix format
     * Use this property to reference the asset
     */
    get path(): string;
    /**
     * Name of the asset
     */
    get fileName(): string;
    private _onSynthesize;
}
