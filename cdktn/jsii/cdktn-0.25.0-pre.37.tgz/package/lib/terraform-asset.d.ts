import { Construct } from "constructs";
import { AssetHashType, IAsset } from "./assets";
export interface TerraformAssetConfig {
    readonly path: string;
    readonly type?: AssetType;
    readonly assetHash?: string;
    /**
     * How the `assetHash` is derived.
     *
     * `SOURCE` (the default) hashes the source path. `CUSTOM` uses the
     * `assetHash` value verbatim and requires it to be set. `OUTPUT` also
     * hashes the source path today — there is no bundling step yet, so the
     * "output" of an asset is its source verbatim — but will hash the
     * bundler's output once bundling is introduced.
     *
     * If `assetHash` is set, this must be `undefined` or `AssetHashType.CUSTOM`.
     *
     * @default AssetHashType.SOURCE
     */
    readonly assetHashType?: AssetHashType;
    /**
     * Paths to exclude from the asset, relative to `path`. See
     * `AssetStagingOptions.exclude` for the accepted forms. Both the computed
     * hash and the staged/packed content honor the exclusion.
     *
     * @default - nothing is excluded
     */
    readonly exclude?: string[];
    /**
     * Extra information to fold into the hash (e.g. build instructions and
     * other inputs).
     *
     * @default - no extra hash
     */
    readonly extraHash?: string;
}
export declare enum AssetType {
    FILE = 0,
    DIRECTORY = 1,
    ARCHIVE = 2
}
export declare class TerraformAsset extends Construct implements IAsset {
    private stack;
    private sourcePath;
    readonly assetHash: string;
    type: AssetType;
    private readonly staging;
    /**
     * A Terraform Asset takes a file or directory outside of the CDK Terrain context and moves it into it.
     * Assets copy referenced files into the stacks context for further usage in other resources.
     * @param scope
     * @param id
     * @param config
     */
    constructor(scope: Construct, id: string, config: TerraformAssetConfig);
    private get namedFolder();
    /**
     * How this asset is written to disk. The layout (directory vs single file)
     * and the artifact name are derived from this rather than from `type`
     * directly, so the two never disagree.
     */
    private get packaging();
    /**
     * The path relative to the root of the terraform directory in posix format
     * Use this property to reference the asset
     */
    get path(): string;
    /**
     * Name of the asset
     */
    get fileName(): string;
    private _onSynthesize;
}
