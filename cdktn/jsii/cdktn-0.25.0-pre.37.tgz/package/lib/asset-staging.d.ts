import { Construct } from "constructs";
import { AssetOptions, IAsset, IAssetPackaging } from "./assets";
import { IIgnoreStrategy } from "./ignore-strategy";
/**
 * Context key for a value folded into every computed asset hash in the
 * construct tree, alongside `extraHash`. A bulk cache-busting escape hatch —
 * `extraHash` is scoped to one asset, this is scoped to the whole app.
 */
export declare const ASSET_HASH_SALT_CONTEXT_KEY = "cdktn:assetHashSalt";
/**
 * Options for {@link AssetStaging}.
 */
export interface AssetStagingOptions extends AssetOptions {
    /**
     * Absolute path to the source file or directory. Resolving a relative path
     * against `cdktf.json` is the caller's responsibility.
     */
    readonly sourcePath: string;
    /**
     * How the staged result is produced and shaped. The caller decides this
     * (e.g. from its own `AssetType`) — `AssetStaging` never infers or changes
     * it based on `exclude`/`extraHash`.
     */
    readonly packaging: IAssetPackaging;
    /**
     * Paths to exclude, relative to `sourcePath`. Cannot be combined with
     * `ignoreStrategy`, which replaces this matcher rather than layering on
     * top of it.
     *
     * @default - nothing is excluded
     */
    readonly exclude?: string[];
    /**
     * Exclusion matching, for callers that need `.gitignore` / `.dockerignore`
     * parity rather than the built-in exact-path / suffix / directory matcher.
     *
     * @default - `exclude` is used with the built-in matcher
     */
    readonly ignoreStrategy?: IIgnoreStrategy;
    /**
     * Extra information to fold into the hash (e.g. build instructions and
     * other inputs).
     *
     * @default - no extra hash
     */
    readonly extraHash?: string;
}
/**
 * Resolves an asset's identity (`SOURCE`/`OUTPUT`/`CUSTOM` hashing, with
 * `exclude`/`extraHash`) and stages it to disk.
 *
 * Hashing happens eagerly in the constructor; staging the content to
 * `targetPath` only happens when `stage()` is called, which callers do from
 * their own `onSynthesize` hook. This keeps the filesystem side effect in the
 * one window where it is safe to run, and keeps this class skippable once a
 * bundler is introduced.
 *
 * `SOURCE` and `OUTPUT` compute identically here: without a bundler, the
 * "output" of an asset is its source verbatim. A future bundler changes what
 * `OUTPUT` hashes, not this class.
 *
 * The source-tree walk behind `SOURCE`/`OUTPUT` is cached per synth (see
 * {@link hashCachesByRoot}), so referencing the same asset from more than one
 * resource or stack hashes it once. `ASSET_HASH_SALT_CONTEXT_KEY` folds an
 * app-wide value into every computed hash, for bulk cache-busting across an
 * entire tree rather than one asset's `extraHash`.
 */
export declare class AssetStaging extends Construct implements IAsset {
    private readonly sourcePath;
    private readonly ignoreStrategy;
    private readonly hashCache;
    readonly packaging: IAssetPackaging;
    readonly isDirectory: boolean;
    readonly assetHash: string;
    constructor(scope: Construct, id: string, props: AssetStagingOptions);
    private resolveAssetHash;
    /**
     * Write the staged content to `targetPath`. Called from the owning
     * construct's `onSynthesize` hook, once the target path is known.
     * @param targetPath - path the packaged result should be written to
     */
    stage(targetPath: string): void;
}
