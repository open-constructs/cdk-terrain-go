/**
 * Minimum CLI version per product required to use a Terraform function.
 * A missing product key means the function is not supported by that product
 * at any version.
 */
export interface FunctionVersionConstraints {
    readonly terraform?: string;
    readonly opentofu?: string;
}
/**
 * Terraform functions that are not universally available across all
 * supported Terraform (>=1.5.7) and OpenTofu
 * (>=1.6.0) releases. Functions absent from this map are
 * available everywhere and need no version validation.
 */
export declare const functionVersionConstraints: Record<string, FunctionVersionConstraints>;
