import { Construct, IConstruct, Node } from "constructs";
import { TerraformElement } from "./terraform-element";
import { TerraformProvider } from "./terraform-provider";
import { TerraformOutput } from "./terraform-output";
import { TerraformRemoteState } from "./terraform-remote-state";
import { IStackSynthesizer } from "./synthesize/types";
import { TerraformBackend } from "./terraform-backend";
import { TerraformResourceTargets } from "./terraform-resource-targets";
export interface TerraformStackMetadata {
    readonly stackName: string;
    readonly version: string;
    readonly backend: string;
    readonly cloud?: string;
}
export declare class TerraformStack extends Construct {
    private readonly rawOverrides;
    private readonly cdktfVersion;
    private crossStackOutputs;
    private crossStackDataSources;
    synthesizer: IStackSynthesizer;
    dependencies: TerraformStack[];
    moveTargets: TerraformResourceTargets;
    /**
     * Terraform functions (`Fn.*`) and provider-defined
     * (`provider::<name>::<function>`) functions actually rendered while
     * resolving THIS stack's own elements during the current synthesis pass.
     *
     * Usage is stack-owned rather than App-owned: `ValidateFunctionVersionSupport`
     * / `ValidateProviderFunctionTargetSupport` are registered in this
     * constructor with the stack itself as scope, and `resolveTargetVersions`
     * walks context up FROM that scope - i.e. from the stack, not the App root.
     * Sibling stacks can therefore declare different `targetVersions` via
     * stack-level `node.setContext`, and a per-App-root usage record would let
     * one stack's usage be validated against a DIFFERENT stack's targets
     * (false positives/negatives depending on which sibling happens to be
     * stricter). Keying usage by the stack that actually rendered it makes
     * each stack's validation see only its own usage, checked against its own
     * targets.
     *
     * Represents the CURRENT synthesis pass only, not the stack's whole
     * lifetime: `_runPreparingResolve` clears both sets at the start of every
     * pass, before re-discovering what that pass actually renders (see
     * `_recordFunctionUsage`/`_recordProviderFunctionUsage`, called from
     * `FunctionCall.resolve()` in `tfExpression.ts`).
     */
    private readonly _usedFunctions;
    /**
     * See `_usedFunctions` - same per-stack, per-pass semantics, for
     * provider-defined (`provider::<name>::<function>`) function calls.
     */
    private readonly _usedProviderFunctions;
    constructor(scope: Construct, id: string);
    static isStack(x: any): x is TerraformStack;
    /**
     * Records that `functionName` (a `Fn.*` Terraform function) was rendered
     * while resolving one of this stack's elements during the current
     * synthesis pass. Called from `FunctionCall.resolve()` in `tfExpression.ts`
     * - see `_usedFunctions` for why usage is stack-owned.
     *
     * @internal
     */
    _recordFunctionUsage(functionName: string): void;
    /**
     * Records that `fullName` (a `provider::<name>::<function>` call) was
     * rendered while resolving one of this stack's elements during the
     * current synthesis pass. Called from `FunctionCall.resolve()` in
     * `tfExpression.ts` - see `_usedFunctions` for why usage is stack-owned.
     *
     * @internal
     */
    _recordProviderFunctionUsage(fullName: string): void;
    /**
     * Returns the `Fn.*` Terraform function names rendered while resolving
     * this stack's elements during the current synthesis pass. Read by
     * `ValidateFunctionVersionSupport`.
     *
     * @internal
     */
    _getUsedFunctions(): string[];
    /**
     * Returns the `provider::<name>::<function>` calls rendered while
     * resolving this stack's elements during the current synthesis pass. Read
     * by `ValidateProviderFunctionTargetSupport`.
     *
     * @internal
     */
    _getUsedProviderFunctions(): string[];
    static of(construct: IConstruct): TerraformStack;
    private findAll;
    prepareStack(): void;
    /**
     * The resolve-discovery half of `prepareStack()`, split out so entry
     * points that must NOT inject a backend (`Testing.synth`/`synthHcl` -
     * doing so would add an implicit local backend to snapshots that never
     * asked for one) can still run the part that discovers current-pass
     * provider-feature and Terraform-function usage.
     *
     * Clears this stack's own `_usedFunctions`/`_usedProviderFunctions` sets
     * first - this stack's per-pass epoch for Terraform-function usage.
     * Because the reset lives here, once per stack, every validation-enabled
     * entry point (`App.synth`, `Testing.synth`/`synthHcl`,
     * `StackSynthesizer.synthesize`) gets it for free just by calling
     * `prepareStack()`/`_runPreparingResolve()` - see `_usedFunctions` for why
     * usage is keyed by stack.
     *
     * Then deactivates every element's stale `resolve-discovered`
     * provider-feature registrations (see
     * `TerraformElement._resetResolveDiscoveredProviderFeatureUsage`) - so
     * usage from an earlier synthesis pass over this same stack can't survive
     * into this one - then resolves every element's `toTerraform()`, which is
     * what re-discovers this pass's actual usage (both provider-feature usage
     * via `markWriteOnlyAttribute`, and Terraform-function usage via
     * `FunctionCall.resolve()`, which records into `_recordFunctionUsage`/
     * `_recordProviderFunctionUsage` above). A preparing resolve run might
     * also add new resources to the stack, e.g. for cross stack references.
     * Cross-stack references stay sound even though this method skips THIS
     * stack's `ensureBackendExists()`: resolving one materializes the ORIGIN
     * stack's backend on demand (`registerIncomingCrossStackReference` calls
     * `fromStack.ensureBackendExists()` itself), so only the synthesizing
     * stack's own backend block is left uninjected - which is exactly what
     * the `Testing.synth`/`synthHcl` callers want.
     *
     * @internal
     */
    _runPreparingResolve(): void;
    addOverride(path: string, value: any): void;
    getLogicalId(tfElement: TerraformElement | Node): string;
    /**
     * Returns the naming scheme used to allocate logical IDs. By default, uses
     * the `HashedAddressingScheme` but this method can be overridden to customize
     * this behavior.
     *
     * @param tfElement The element for which the logical ID is allocated.
     */
    protected allocateLogicalId(tfElement: TerraformElement | Node): string;
    allProviders(): TerraformProvider[];
    ensureBackendExists(): TerraformBackend;
    toHclTerraform(): {
        [key: string]: any;
    };
    toTerraform(): any;
    registerOutgoingCrossStackReference(identifier: string): TerraformOutput;
    registerIncomingCrossStackReference(fromStack: TerraformStack): TerraformRemoteState;
    dependsOn(stack: TerraformStack): boolean;
    addDependency(dependency: TerraformStack): void;
    /**
     * Run all validations on the stack.
     */
    runAllValidations(): void;
    hasResourceMove(): boolean;
}
