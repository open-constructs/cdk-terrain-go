import { Construct } from "constructs";
import { TerraformStack } from "./terraform-stack";
import { ProviderFeature } from "./provider-feature-constraints";
export interface TerraformElementMetadata {
    readonly path: string;
    readonly uniqueId: string;
    readonly stackTrace: string[];
}
export declare class TerraformElement extends Construct {
    protected readonly rawOverrides: any;
    /**
     * An explicit logical ID provided by `overrideLogicalId`.
     */
    private _logicalIdOverride?;
    /**
     * Type of this element, used for fqn.
     * This is undefined for
     * - elements not referable, like TerraformOutput
     * - elements using their own fqn implementation, like TerraformProvider
     */
    private readonly _elementType?;
    /**
     * Provider-protocol feature families (see `ProviderFeature`) already
     * registered on this element via `registerProviderFeatureUsage` or
     * `_registerResolveDiscoveredProviderFeatureUsage`, so repeated usage
     * (e.g. a setter called multiple times, or the same value resolved more
     * than once in a synthesis pass) doesn't stack duplicate synth-time
     * validations - each feature installs at most one node validation for
     * the lifetime of the element, gated on/off via the registration's
     * `active` flag instead of being re-added or removed.
     *
     * Lazily allocated: most elements in a large stack never register a
     * provider feature at all, so this stays `undefined` until the first
     * registration instead of every `TerraformElement` paying for an empty
     * `Map` it will never use.
     */
    private _registeredProviderFeatures?;
    constructor(scope: Construct, id: string, elementType?: string);
    get cdktfStack(): TerraformStack;
    static isTerraformElement(x: any): x is TerraformElement;
    /**
     * Registers a synth-time validation that the project's declared
     * targetVersions admit the given provider-protocol feature family.
     * Called by generated provider bindings when a versioned feature is
     * structurally in use - the element's existence in the construct tree
     * already implies the feature is used, e.g. constructing a
     * `TerraformEphemeralResource` at all - so, unlike
     * `_registerResolveDiscoveredProviderFeatureUsage`, this registration is
     * never deactivated by `_resetResolveDiscoveredProviderFeatureUsage`. Not
     * intended to be called directly by user code. Lives on `TerraformElement`
     * (rather than `TerraformResource`) so it covers any element subclass
     * that needs it.
     */
    protected registerProviderFeatureUsage(feature: ProviderFeature): void;
    /**
     * Registers (or re-arms) a synth-time validation for a provider-protocol
     * feature family whose usage is only known once a value is resolved
     * during synthesis - e.g. `markWriteOnlyAttribute`'s wrapper, which calls
     * this from its `resolve()` closure only when the resolved value turns
     * out to be a real, renderable value.
     *
     * Unlike `registerProviderFeatureUsage`, a registration made through this
     * method represents usage discovered during the CURRENT synthesis pass
     * only: `_resetResolveDiscoveredProviderFeatureUsage` deactivates it at
     * the start of each pass, and calling this method again re-activates it
     * without installing a second, duplicate node validation. Every
     * validation-enabled entry point (`App.synth`, `Testing.synth`/
     * `synthHcl` with validations, `StackSynthesizer.synthesize`) runs a
     * prepare step that performs this reset-then-rediscover cycle before
     * validations run, so what a validation sees always reflects only the
     * pass that is about to be validated.
     *
     * @internal
     */
    _registerResolveDiscoveredProviderFeatureUsage(feature: ProviderFeature): void;
    /**
     * Deactivates every `resolve-discovered` provider-feature registration on
     * this element (structural registrations are left untouched - see
     * `ProviderFeatureRegistrationMode`). Called once per synthesis pass,
     * before that pass's preparing resolve re-discovers whatever usage
     * actually renders during it - see `TerraformStack._runPreparingResolve`.
     *
     * @internal
     */
    _resetResolveDiscoveredProviderFeatureUsage(): void;
    private _registerProviderFeature;
    toTerraform(): any;
    toHclTerraform(): any;
    toMetadata(): any;
    private _fqnToken?;
    get fqn(): string;
    private _friendlyUniqueId?;
    get friendlyUniqueId(): string;
    /**
     * Overrides the auto-generated logical ID with a specific ID.
     * @param newLogicalId The new logical ID to use for this stack element.
     */
    overrideLogicalId(newLogicalId: string): void;
    /**
     * Resets a previously passed logical Id to use the auto-generated logical id again
     */
    resetOverrideLogicalId(): void;
    addOverride(path: string, value: any): void;
    protected get constructNodeMetadata(): {
        [key: string]: any;
    };
}
