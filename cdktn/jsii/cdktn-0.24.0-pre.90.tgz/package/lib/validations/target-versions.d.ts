import { IConstruct, IValidation } from "constructs";
import { TerraformFeatureVersionConstraints } from "./validate-terraform-feature-version";
/**
 * Context key carrying the project's declared Terraform-compatible runtime
 * targets (set from the `targetVersions` field in cdktf.json by the CLI, or
 * directly via App context / CDKTF_CONTEXT_JSON for standalone synth).
 *
 * This is the canonical definition. `@cdktn/commons` imports it from here
 * (commons depends on cdktn; cdktn must not depend on commons), so the CLI
 * writes and the construct library reads the exact same key. It is an
 * internal wiring detail, deliberately not part of cdktn's public API.
 */
export declare const TARGET_VERSIONS_CONTEXT_KEY = "targetVersions";
/**
 * The Terraform-compatible runtimes a project declares it supports, as npm
 * semver ranges per product. A missing product means the project does not
 * target that product.
 */
export interface TerraformTargetVersions {
    readonly terraform?: string;
    readonly opentofu?: string;
}
/**
 * Used when a project declares no `targetVersions`: the project is assumed
 * to target every supported release of both products, which is the strictest
 * (most portable) interpretation.
 */
export declare const DEFAULT_TARGET_VERSIONS: TerraformTargetVersions;
/**
 * The product keys a project may declare targets for. Exported for reuse by
 * `@cdktn/commons` (imported via subpath), not part of cdktn's public API.
 */
export declare const TARGET_PRODUCTS: readonly ["terraform", "opentofu"];
/**
 * Resolves the declared target versions from construct context, falling back
 * to DEFAULT_TARGET_VERSIONS. Returns errors instead of targets when the
 * declared value is malformed (which can happen when context is set directly
 * on the App rather than going through cdktf.json validation).
 */
export declare function resolveTargetVersions(scope: IConstruct): {
    targets?: TerraformTargetVersions;
    errors: string[];
};
/**
 * Checks whether a feature is supported across the entire declared target
 * range of every targeted product.
 *
 * `supportedIn` follows the TerraformFeatureVersionConstraints semantics: a
 * missing product key means the feature is not supported by that product at
 * any version. The check is a semver range subset: declaring
 * `terraform: ">=1.5.7"` while a feature requires `>=1.8.0` fails, because
 * the project claims to support 1.5.7..1.8.0 where the feature is missing.
 */
export declare function checkFeatureSupportedByTargets(featureName: string, supportedIn: TerraformFeatureVersionConstraints, targets: TerraformTargetVersions, hint?: string): string[];
/**
 * Validates that a feature is supported by the project's declared
 * Terraform-compatible runtime targets (cdktf.json `targetVersions`),
 * without probing any locally installed binary.
 *
 * Verifying the actually installed binary is a separate, explicit step:
 * the opt-in `validateInstalledBinary` config handled by the CLI commands
 * that execute the binary.
 */
export declare class ValidateFeatureTargetSupport implements IValidation {
    protected scope: IConstruct;
    protected featureName: string;
    protected supportedIn: TerraformFeatureVersionConstraints;
    protected hint?: string | undefined;
    constructor(scope: IConstruct, featureName: string, supportedIn: TerraformFeatureVersionConstraints, hint?: string | undefined);
    validate(): string[];
}
