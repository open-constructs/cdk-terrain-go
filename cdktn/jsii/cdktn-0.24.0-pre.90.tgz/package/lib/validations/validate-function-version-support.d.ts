import { IConstruct, IValidation } from "constructs";
/**
 * Validates that every Terraform function used through `Fn` is supported by
 * the project's declared Terraform/OpenTofu targets (cdktf.json
 * `targetVersions`, defaulting to the dual product baseline).
 *
 * Most functions are universally available and are not checked at all; only
 * functions listed in the generated availability map are validated. The
 * check is purely declarative — no binary is executed — so synth behaves
 * identically in CI, package builds, and environments without Terraform or
 * OpenTofu installed. Verifying the actually installed binary is the
 * separate, opt-in `validateInstalledBinary` CLI behavior.
 *
 * Functions used via raw escape hatches (overrides, hand-written expression
 * strings) are not tracked and therefore not validated.
 *
 * Usage is read from the OWNING STACK (`TerraformStack._getUsedFunctions()`)
 * rather than from `node.root`: this validation is registered in
 * `TerraformStack`'s constructor with the stack itself as scope, and
 * `resolveTargetVersions` below walks context up from that same scope, so a
 * per-stack `targetVersions` override is possible - reading a root-keyed
 * (App-wide) usage record would validate one stack's usage against a
 * sibling stack's targets. See `TerraformStack._usedFunctions` for the full
 * rationale.
 */
export declare class ValidateFunctionVersionSupport implements IValidation {
    protected scope: IConstruct;
    constructor(scope: IConstruct);
    validate(): string[];
}
