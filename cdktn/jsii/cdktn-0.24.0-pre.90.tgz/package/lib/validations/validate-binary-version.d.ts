import { IValidation } from "constructs";
/**
 * A validation that can be applied to a construct that will error if the
 * construct is being used in an environment with a version of a binary lower than the specified version.
 *
 * TODO(target-versions): legacy synth-time binary probe that predates
 * OpenTofu support and the declared `targetVersions` model. Existing
 * consumers (e.g. ValidateTerraformVersion for resource moves) should
 * migrate to ValidateFeatureTargetSupport, leaving installed-binary
 * verification to the opt-in validateInstalledBinary CLI behavior. Left
 * unchanged here only to keep this PR small; the migration is tracked in
 * #275. Note this class is not exported from the cdktn package root, so the
 * change is behavioral (synth no longer shelling out), not a symbol-level
 * public-API break.
 */
export declare class ValidateBinaryVersion implements IValidation {
    protected binary: string;
    protected versionConstraint: string;
    protected versionCommand: string;
    protected hint?: string | undefined;
    constructor(binary: string, versionConstraint: string, versionCommand: string, hint?: string | undefined);
    validate(): string[];
}
