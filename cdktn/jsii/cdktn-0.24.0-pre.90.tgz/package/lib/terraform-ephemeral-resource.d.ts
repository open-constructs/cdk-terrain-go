import { Construct } from "constructs";
import { TerraformElement } from "./terraform-element";
import { TerraformProvider } from "./terraform-provider";
import { TerraformProviderGeneratorMetadata } from "./terraform-resource";
import { Precondition, Postcondition } from "./terraform-conditions";
import { ITerraformDependable } from "./terraform-dependable";
import { IResolvable } from "./tokens/resolvable";
import { IInterpolatingParent } from "./terraform-addressable";
import { ITerraformIterator } from "./terraform-iterator";
import { TerraformCount } from "./terraform-count";
/**
 * Lifecycle options supported by Terraform ephemeral blocks. Unlike managed
 * resources, ephemeral resources have no state, so Terraform only supports
 * `precondition`/`postcondition` here - `createBeforeDestroy`,
 * `preventDestroy`, `ignoreChanges`, and `replaceTriggeredBy` are all
 * state-oriented concepts that do not apply.
 */
export interface TerraformEphemeralResourceLifecycle {
    readonly precondition?: Precondition[];
    readonly postcondition?: Postcondition[];
}
export interface ITerraformEphemeralResource {
    readonly terraformResourceType: string;
    readonly fqn: string;
    readonly friendlyUniqueId: string;
    dependsOn?: string[];
    count?: number | TerraformCount;
    provider?: TerraformProvider;
    lifecycle?: TerraformEphemeralResourceLifecycle;
    forEach?: ITerraformIterator;
    interpolationForAttribute(terraformAttribute: string): IResolvable;
}
/**
 * Meta-arguments accepted by ephemeral resources. Terraform ephemeral blocks
 * do not support provisioners or connection blocks, unlike managed resources.
 */
export interface TerraformEphemeralMetaArguments {
    readonly dependsOn?: ITerraformDependable[];
    readonly count?: number | TerraformCount;
    readonly provider?: TerraformProvider;
    readonly lifecycle?: TerraformEphemeralResourceLifecycle;
    readonly forEach?: ITerraformIterator;
}
export interface TerraformEphemeralResourceConfig extends TerraformEphemeralMetaArguments {
    readonly terraformResourceType: string;
    readonly terraformGeneratorMetadata?: TerraformProviderGeneratorMetadata;
}
export declare class TerraformEphemeralResource extends TerraformElement implements ITerraformEphemeralResource, ITerraformDependable, IInterpolatingParent {
    readonly terraformResourceType: string;
    readonly terraformGeneratorMetadata?: TerraformProviderGeneratorMetadata;
    dependsOn?: string[];
    count?: number | TerraformCount;
    provider?: TerraformProvider;
    lifecycle?: TerraformEphemeralResourceLifecycle;
    forEach?: ITerraformIterator;
    constructor(scope: Construct, id: string, config: TerraformEphemeralResourceConfig);
    static isTerraformEphemeralResource(x: any): x is TerraformEphemeralResource;
    getStringAttribute(terraformAttribute: string): string;
    getNumberAttribute(terraformAttribute: string): number;
    getListAttribute(terraformAttribute: string): string[];
    getBooleanAttribute(terraformAttribute: string): IResolvable;
    getNumberListAttribute(terraformAttribute: string): number[];
    getStringMapAttribute(terraformAttribute: string): {
        [key: string]: string;
    };
    getNumberMapAttribute(terraformAttribute: string): {
        [key: string]: number;
    };
    getBooleanMapAttribute(terraformAttribute: string): {
        [key: string]: boolean;
    };
    getAnyMapAttribute(terraformAttribute: string): {
        [key: string]: any;
    };
    get terraformMetaArguments(): {
        [name: string]: any;
    };
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
    /**
     * Adds this ephemeral resource to the terraform JSON output.
     */
    toTerraform(): any;
    toHclTerraform(): any;
    toMetadata(): any;
    interpolationForAttribute(terraformAttribute: string): IResolvable;
}
