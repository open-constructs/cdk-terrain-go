/**
 *
 */
export declare function cleanForMetadata(block: any): any;
/**
 *
 */
export declare function renderList(v: any, name?: string): string;
/**
 *
 */
export declare function renderListValue(value: any, storageClassType: string): string;
/**
 *
 */
export declare function renderMap(map: any): string;
/**
 *
 */
export declare function renderMapValue(value: any): string;
/**
 *
 */
export declare function renderResource(resource: any): {
    hcl: string;
    metadata: {
        resource: {
            [x: string]: {
                [x: string]: {
                    "//": any;
                };
            };
        };
    };
};
/**
 *
 */
export declare function renderDatasource(dataSource: any): {
    hcl: string;
    metadata: {
        data: {
            [x: string]: {
                [x: string]: {
                    "//": any;
                };
            };
        };
    };
};
/**
 *
 */
export declare function renderEphemeral(ephemeral: any): {
    hcl: string;
    metadata: {
        ephemeral: {
            [x: string]: {
                [x: string]: {
                    "//": any;
                };
            };
        };
    };
};
/**
 *
 */
export declare function renderProvisionerBlock(provisioners: any): any;
/**
 *
 */
export declare function renderDynamicBlocks(dynamic: any): string[];
/**
 *
 */
export declare function renderProvider(provider: any): any;
/**
 *
 */
export declare function renderModule(module: any): {
    hcl: string;
    metadata: {
        module: {
            [x: string]: {
                "//": any;
            };
        };
    };
};
/**
 *
 */
export declare function renderOutput(output: any): string;
/**
 *
 */
export declare function renderLocals(locals: any): string;
/**
 *
 */
export declare function renderVariable(variable: any): string;
/**
 *
 */
export declare function renderMoved(move: any): any;
/**
 *
 */
export declare function renderImport(imports: any): any;
/**
 *
 */
export declare function renderTerraform(terraform: any): string;
/**
 *
 */
export declare function renderBlock(block: any, _storageClassType: string): string;
/**
 *
 */
export declare function renderSimpleAttributes(attributes: any): string;
/**
 *
 */
export declare function renderAttributes(attributes: any): string;
