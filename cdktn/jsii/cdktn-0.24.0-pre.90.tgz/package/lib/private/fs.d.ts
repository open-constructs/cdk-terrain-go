/**
 * Copy a file or directory. The directory can have contents and subfolders.
 * @param src - source path
 * @param dest - destination path
 */
export declare function copySync(src: string, dest: string): void;
/**
 * Zips contents at src and places zip archive at dest.
 * @param src - directory to archive
 * @param dest - path to write the resulting zip to
 */
export declare function archiveSync(src: string, dest: string): void;
export interface HashPathOptions {
    /**
     * Use the canonical entry-framed hash instead of the legacy
     * content-concatenation hash. Enabled through the `canonicalAssetHashes`
     * feature flag.
     */
    readonly canonical?: boolean;
    /**
     * Frame for an archive artifact: archiveSync never emits ZIP directory
     * entries, so canonical hashing omits directory records and the hash
     * tracks the emitted archive bytes exactly. Non-empty directories stay
     * visible through the relative paths of their contents. Has no effect on
     * the legacy scheme, which never records directories.
     */
    readonly archive?: boolean;
}
/**
 * Compute a stable MD5 hash of a file or directory's contents.
 * In both schemes symlinks are hashed by their metadata (path + target)
 * instead of being followed, so shared targets are not double-counted and
 * cycles cannot recurse; a symlink at the root itself is followed, matching
 * how the asset source path is opened when the artifact is emitted.
 * @param src - path to a file or directory to hash
 * @param options - hash scheme selection, see {@link HashPathOptions}
 * @returns uppercased hex digest, truncated to HASH_LEN characters
 */
export declare function hashPath(src: string, options?: HashPathOptions): string;
/**
 * Walk upward from `rootPath` looking for a file with the given name.
 * Returns the absolute path of the first match, or `null` if the search
 * reaches the filesystem root without finding it.
 * @param file - filename to search for
 * @param rootPath - directory to start the search from (defaults to cwd)
 * @returns absolute path to the file, or null if not found
 */
export declare function findFileAboveCwd(file: string, rootPath?: string): string | null;
