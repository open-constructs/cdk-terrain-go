export interface TerraformConstructor {
    readonly tfResourceType: string;
}
export type SynthesizedStack = {
    resource: Record<string, any>;
    data: Record<string, any>;
    provider: Record<string, any>;
};
/**
 * The result of a testing matcher assertion.
 */
export declare class AssertionReturn {
    readonly message: string;
    readonly pass: boolean;
    constructor(message: string, pass: boolean);
}
export type MatcherReturnJest = {
    message: () => string;
    pass: boolean;
};
/**
 * Adapts an {@link AssertionReturn} to Jest's `{ message, pass }` matcher shape.
 */
export declare function returnMatcherToJest(toReturn: AssertionReturn): MatcherReturnJest;
/**
 * Deep-equals `expected` against `received`, ignoring extra properties on `received` and
 * matching each key in either camelCase or snake_case.
 */
export declare function asymetricDeepEqualIgnoringObjectCasing(expected: unknown, received: unknown): boolean;
/**
 * Returns a `toHaveDataSourceWithProperties` matcher using `customPassEvaluation` to decide a
 * match.
 */
export declare function getToHaveDataSourceWithProperties(customPassEvaluation?: (items: any, assertedProperties: Record<string, any>) => boolean): (received: string, resourceType: TerraformConstructor, properties?: Record<string, any>) => AssertionReturn;
/**
 * Returns a `toHaveResourceWithProperties` matcher using `customPassEvaluation` to decide a
 * match.
 */
export declare function getToHaveResourceWithProperties(customPassEvaluation?: (items: any, assertedProperties: Record<string, any>) => boolean): (received: string, resourceType: TerraformConstructor, properties?: Record<string, any>) => AssertionReturn;
/**
 * Returns a `toHaveProviderWithProperties` matcher using `customPassEvaluation` to decide a
 * match.
 */
export declare function getToHaveProviderWithProperties(customPassEvaluation?: (items: any, assertedProperties: Record<string, any>) => boolean): (received: string, resourceType: TerraformConstructor, properties?: Record<string, any>) => AssertionReturn;
/**
 * Resolves and caches a `.terraform.lock.hcl` for every unique required-providers set across
 * the given `fullSynth` output directories, up front and serially.
 *
 * Intended for callers that know the full set of stacks under test ahead of time — e.g. a
 * Jest/Vitest `globalSetup` hook, before parallel workers start — so there's nothing left for
 * `toBeValidTerraform`/`toPlanSuccessfully` to race over
 * (https://github.com/open-constructs/cdk-terrain/issues/452).
 *
 * @param received one or more `fullSynth` output directories to warm up
 */
export declare function warmUpProviderLockFileCache(received: string[]): void;
/**
 * Checks that the received stack is valid Terraform (`terraform validate`).
 */
export declare function toBeValidTerraform(received: string): AssertionReturn;
export interface ToPlanSuccessfullyOptions {
    /**
     * Whether `init`/`plan` should use the stack's real backend. Disable this for stacks whose
     * backend (e.g. s3, remote) is not reachable in the test environment and whose plan does not
     * depend on existing state.
     * @default true
     */
    readonly backend?: boolean;
}
/**
 * Checks that the received stack plans successfully (`terraform plan`).
 */
export declare function toPlanSuccessfully(received: string, options?: ToPlanSuccessfullyOptions): AssertionReturn;
