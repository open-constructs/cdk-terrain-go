/**
 * Copy a file or directory. The directory can have contents and subfolders.
 * @param src - source path
 * @param dest - destination path
 */
export declare function copySync(src: string, dest: string): void;
/**
 * Zips contents at src and places zip archive at dest.
 * @param src - directory to archive
 * @param dest - path to write the resulting zip to
 */
export declare function archiveSync(src: string, dest: string): void;
/**
 * Compute a stable MD5 hash of a file or directory's contents.
 * File contents fold into one digest in directory-listing order, exactly as
 * earlier releases did, so trees without symlinks keep their historical
 * hashes. Symlinks are hashed by their metadata (path + target) instead of
 * being followed, so shared targets are not double-counted and cycles cannot
 * recurse; that metadata goes into a second digest, and only when symlinks
 * exist are the two combined under a tagged outer hash — the tag keeps
 * symlink metadata in a separate domain from file bytes, so a file
 * containing `foo` can never collide with a symlink targeting `foo`.
 * @param src - path to a file or directory to hash
 * @returns uppercased hex digest, truncated to HASH_LEN characters
 */
export declare function hashPath(src: string): string;
/**
 * Walk upward from `rootPath` looking for a file with the given name.
 * Returns the absolute path of the first match, or `null` if the search
 * reaches the filesystem root without finding it.
 * @param file - filename to search for
 * @param rootPath - directory to start the search from (defaults to cwd)
 * @returns absolute path to the file, or null if not found
 */
export declare function findFileAboveCwd(file: string, rootPath?: string): string | null;
