/**
 * Captures a complete stack trace at the point of invocation.
 */
export declare function captureStackTrace(below?: Function): string[];
/**
 * Captures a stack trace for a resolvable's `creationStack`, unless disabled
 * via the `CDKTN_DISABLE_CREATION_STACK` env var. When disabled, returns `[]`
 * to skip the (expensive) `Error.captureStackTrace` call.
 */
export declare function captureCreationStack(): string[];
