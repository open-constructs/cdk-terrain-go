import { IResolvable } from "../tokens/resolvable";
/**
 * Runtime entry point invoked by generated provider function bindings
 * (`providers/<provider>/provider-functions/index.ts`). Generated code only
 * imports the public `cdktn` package root, so this is the single chokepoint
 * through which every provider-defined function call flows.
 */
export declare class TerraformProviderFunction {
    /**
     * Invokes a provider-defined function (Terraform's
     * `provider::<providerLocalName>::<functionName>(...)` syntax).
     *
     * Note: provider-defined functions are evaluated by the provider itself —
     * do not call this inside the configuration of the same provider
     * (Terraform reports a self-referential cycle).
     *
     * @param providerLocalName the local name of the provider as declared in
     * `required_providers` (defaults to the registry short name; callers may
     * override this when the provider is aliased under a different local
     * name — aliases do not change the namespace, local names do)
     * @param functionName the provider-defined function name (snake_case, as
     * published in the provider schema)
     * @param args the function arguments, positional (in declared order). Each
     * entry in `args` maps 1:1 to a positional slot in the rendered call — a
     * `null` or `undefined` entry keeps its slot and renders as the Terraform
     * `null` keyword, it is not dropped. Callers that flatten a genuinely
     * variadic trailing parameter (`[a, ...values]`) get one positional slot
     * per flattened element, which is the desired behavior.
     */
    static invoke(providerLocalName: string, functionName: string, args: any[]): IResolvable;
    private constructor();
}
