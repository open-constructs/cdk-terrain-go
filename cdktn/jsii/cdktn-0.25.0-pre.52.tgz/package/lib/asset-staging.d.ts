import { Construct } from "constructs";
import { AssetOptions, IAsset, IAssetBundler, IAssetPackaging } from "./assets";
import { IIgnoreStrategy } from "./ignore-strategy";
/**
 * Context key for a value folded into every computed asset hash in the
 * construct tree, alongside `extraHash`. A bulk cache-busting escape hatch —
 * `extraHash` is scoped to one asset, this is scoped to the whole app.
 */
export declare const ASSET_HASH_SALT_CONTEXT_KEY = "cdktn:assetHashSalt";
/**
 * Options for {@link AssetStaging}.
 */
export interface AssetStagingOptions extends AssetOptions {
    /**
     * Absolute path to the source file or directory. Resolving a relative path
     * against `cdktf.json` is the caller's responsibility.
     */
    readonly sourcePath: string;
    /**
     * How the staged result is produced and shaped. The caller decides this
     * (e.g. from its own `AssetType`) — `AssetStaging` never infers or changes
     * it based on `exclude`/`extraHash`.
     */
    readonly packaging: IAssetPackaging;
    /**
     * Paths to exclude, relative to `sourcePath`. Cannot be combined with
     * `ignoreStrategy`, which replaces this matcher rather than layering on
     * top of it.
     *
     * @default - nothing is excluded
     */
    readonly exclude?: string[];
    /**
     * Exclusion matching, for callers that need `.gitignore` / `.dockerignore`
     * parity rather than the built-in exact-path / suffix / directory matcher.
     *
     * @default - `exclude` is used with the built-in matcher
     */
    readonly ignoreStrategy?: IIgnoreStrategy;
    /**
     * Extra information to fold into the hash (e.g. build instructions and
     * other inputs).
     *
     * @default - no extra hash
     */
    readonly extraHash?: string;
    /**
     * A bundler that builds the source into an artifact before staging.
     *
     * Under the default `SOURCE` hashing the build is deferred to `stage()` and
     * stays skippable; `OUTPUT` hashing builds eagerly at construction time to
     * hash the artifact, forgoing skippability. The bundler's declared output
     * shape must match the packaging: a `BundleResult.directory` needs a
     * directory-accepting packaging, a `BundleResult.file` a single-file one
     * (`AssetType.FILE`). The mismatch is caught once the build runs.
     *
     * @default - the source is staged verbatim, with no build step
     */
    readonly bundler?: IAssetBundler;
    /**
     * Identifier used in error messages, so they name the user-facing construct
     * (e.g. the `TerraformAsset`) rather than this internal staging child.
     *
     * @default - the staging construct's own id
     */
    readonly displayName?: string;
}
/**
 * Resolves an asset's identity and stages its content to disk.
 *
 * The hash is available immediately after construction; the filesystem write
 * is deferred to `stage()`, the one window where it is safe. Hashing is
 * cached per synth (see {@link hashCachesByRoot}) so an asset referenced from
 * several places is walked once. Without a bundler, `SOURCE` and `OUTPUT` both
 * hash the source; with one they diverge, as `AssetStagingOptions.bundler`
 * describes.
 */
export declare class AssetStaging extends Construct implements IAsset {
    private readonly sourcePath;
    private readonly displayName;
    private readonly ignoreStrategy;
    private readonly hasExclusions;
    private readonly hashCache;
    private readonly bundler?;
    /**
     * Output of an eager `OUTPUT`-hash build, carried to `stage()` for reuse.
     *
     * Undefined on every other path, where the build is deferred or absent.
     */
    private eagerBuild?;
    /**
     * Set once `stage()` has run, so a second call cannot rebuild. An eager
     * `OUTPUT` build is captured at construction and consumed by the first
     * `stage()`; without this guard a second call would fall through to the
     * deferred build path and stage bytes that no longer match the hash.
     */
    private staged;
    readonly packaging: IAssetPackaging;
    readonly isDirectory: boolean;
    readonly assetHash: string;
    constructor(scope: Construct, id: string, props: AssetStagingOptions);
    private resolveAssetHash;
    /**
     * Hash the source tree, honoring the ignore strategy.
     *
     * Cached per synth so an asset referenced more than once is walked once.
     */
    private hashSource;
    /**
     * Build the bundler's output eagerly and hash the built artifact.
     *
     * The output is stashed for `stage()` to reuse, so the build is not
     * repeated. It is hashed verbatim: `exclude` filters the source a bundler
     * reads, not the artifact it produces.
     */
    private hashOutput;
    /**
     * Run the bundler against the filtered source and return its output.
     *
     * The bundler is handed an absolute `source` (its cwd is its own, so a
     * relative path would resolve elsewhere) that has already had `exclude`
     * applied. Materialising the filtered input here is what makes the bundler
     * read exactly the tree the hash was taken over, which a raw source
     * hand-off would not, since `hashSource` honours `exclude`.
     */
    private runBundle;
    /**
     * Reject a bundler result whose declared shape does not match what is on
     * disk, or does not match the packaging.
     *
     * Catching the mismatch here turns an opaque EISDIR/EPERM at pack time into
     * a clear error naming the packaging the bundler's output shape needs.
     */
    private validateOutputShape;
    /**
     * Whether the packaging stages a single file verbatim (AssetType.FILE).
     *
     * A verbatim-file packaging neither produces a directory nor reads one as
     * its source. Derived from existing `IAssetPackaging` flags so out-of-tree
     * packagings need no new interface member.
     */
    private get stagesSingleFile();
    /**
     * Absolute path to the source the bundler should read.
     *
     * With no exclusions, or with a file source, the resolved source is handed
     * over directly — a file has no children to filter, matching `hashSource`,
     * which only ever applies the ignore strategy to a directory's entries and
     * never to the root itself. Otherwise the excluded source tree is
     * materialised into the scratch directory, so the bundler sees the same
     * file set the hash was taken over.
     */
    private filteredSource;
    /**
     * Stage the asset's content to `targetPath`.
     *
     * Called from the owning construct's `onSynthesize` hook. Without a bundler
     * the source is packaged verbatim; with one, the bundler's output is, built
     * eagerly for `OUTPUT` hashing or deferred to here for `SOURCE`.
     */
    stage(targetPath: string): void;
    /**
     * Remove a bundler scratch directory and drop it from the exit-sweep set.
     */
    private cleanupScratch;
    /**
     * Package a bundler's output into `targetPath`, verbatim.
     *
     * The output's shape was already validated against the packaging in
     * {@link runBundle}, so the packaging handles the source directly — a file
     * source for AssetType.FILE, a directory source otherwise.
     *
     * The ignore strategy is deliberately not applied. `exclude` filters the
     * source a bundler reads, not its product: an install-style bundler
     * (`npm install --production`, `pip install -t`) writes exactly the
     * dependency directory a user excludes from source, and re-applying the
     * exclusion would ship an artifact missing those dependencies.
     */
    private packBundlerOutput;
}
