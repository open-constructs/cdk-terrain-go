export declare function recordFunctionUsage(functionName: string): void;
export declare function getUsedFunctions(): string[];
/**
 * Clears the recorded function usage; intended for tests.
 */
export declare function resetFunctionUsageRegistry(): void;
