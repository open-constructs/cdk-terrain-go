import { IConstruct } from "constructs";
/**
 * Checks whether `required_version` should be written from `targetVersions` for the given scope: `targetVersions` is
 * declared, rather than falling back to the defaults.
 * @param scope - construct whose context is read, usually a stack
 * @returns true if the settings files should be written
 */
export declare function writesRequiredVersion(scope: IConstruct): boolean;
/**
 * Writes a settings file for each product in `targetVersions` into the stack's working directory, in the stack's
 * output format:
 *
 * - A product that isn't targeted gets no file, except that an OpenTofu-only project also writes its OpenTofu
 *   constraint to the Terraform file, which OpenTofu 1.6 and 1.7 read in place of the OpenTofu file.
 * - A product whose range allows every version gets a file without `required_version`, so that OpenTofu doesn't
 *   fall back to the Terraform constraint.
 * - A range with alternatives (`||`) can't be written as a constraint. It adds a warning, and the Terraform file is
 *   skipped, or the OpenTofu file is written without `required_version`.
 * - If targeted OpenTofu releases before 1.8 would be rejected by the Terraform constraint, it adds a warning and
 *   skips the Terraform file.
 * @param scope - construct whose `targetVersions` context is read and that receives warnings, usually a stack
 * @param workingDirectory - absolute path of the stack's working directory
 * @param hclOutput - whether to write `settings.tf` / `settings.tofu` instead of `settings.tf.json` /
 * `settings.tofu.json`
 */
export declare function writeRequiredVersionFiles(scope: IConstruct, workingDirectory: string, hclOutput: boolean): void;
/**
 * Removes the settings files, in either format, written by a previous synth, so they don't outlive a change to
 * `targetVersions` or the output format.
 * @param workingDirectory - absolute path of the stack's working directory
 */
export declare function removeRequiredVersionFiles(workingDirectory: string): void;
