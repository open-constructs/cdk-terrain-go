/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
/**
 * Serializes an object key fragment as the inner content of a Terraform
 * quoted-string literal, without the surrounding quotes.
 *
 * `JSON.stringify` covers quotes, backslashes and most control characters.
 * Terraform quoted strings reject the `\b` and `\f` escapes that JSON emits, so
 * those use four-digit Unicode escapes. `$${` and `%%{` are the Terraform
 * escapes for sequences that would otherwise start a template interpolation or
 * directive.
 *
 * Set `keepTemplates` when the fragment may hold a resolved token, which
 * renders as a `${...}` reference that must stay an interpolation.
 */
export declare function quotedStringKeyFragment(fragment: string, keepTemplates?: boolean): string;
/**
 * Serializes an object key as a Terraform quoted-string literal.
 *
 * Set `keepTemplates` when the key may hold a resolved token, which renders as
 * a `${...}` reference that must stay an interpolation.
 */
export declare function quotedStringKey(key: string, keepTemplates?: boolean): string;
