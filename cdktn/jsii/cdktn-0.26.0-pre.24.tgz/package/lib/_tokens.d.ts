import { Construct } from "constructs";
/**
 * Resolves all tokens in an object using the default token resolver
 * @param scope The construct the tokens are resolved in
 * @param obj The object to resolve
 * @param preparing Whether this is the preparation pass rather than the final resolution
 * @returns The object with all tokens resolved
 */
export declare function resolve<T>(scope: Construct, obj: T, preparing?: boolean): T;
