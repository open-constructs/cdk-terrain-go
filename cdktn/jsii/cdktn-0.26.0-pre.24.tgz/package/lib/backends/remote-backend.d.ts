import { Construct } from "constructs";
import { TerraformBackend } from "../terraform-backend";
import { TerraformRemoteState, DataTerraformRemoteStateConfig } from "../terraform-remote-state";
/**
 * Configures the stack to store its Terraform state in the `remote` backend.
 */
export declare class RemoteBackend extends TerraformBackend {
    private readonly props;
    constructor(scope: Construct, props: RemoteBackendConfig);
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
    toMetadata(): any;
    getRemoteStateDataSource(scope: Construct, name: string, _fromStack: string): TerraformRemoteState;
}
/**
 * A `terraform_remote_state` data source that reads the outputs of a state stored in the `remote` backend.
 */
export declare class DataTerraformRemoteState extends TerraformRemoteState {
    constructor(scope: Construct, id: string, config: DataTerraformRemoteStateRemoteConfig);
}
export interface RemoteBackendConfig {
    readonly hostname?: string;
    readonly organization: string;
    readonly token?: string;
    readonly workspaces: IRemoteWorkspace;
}
export interface IRemoteWorkspace {
}
/**
 * Selects a single `remote` backend workspace by its full name.
 */
export declare class NamedRemoteWorkspace implements IRemoteWorkspace {
    name: string;
    constructor(name: string);
}
/**
 * Selects every `remote` backend workspace whose name starts with the given prefix.
 */
export declare class PrefixedRemoteWorkspaces implements IRemoteWorkspace {
    prefix: string;
    constructor(prefix: string);
}
export interface DataTerraformRemoteStateRemoteConfig extends DataTerraformRemoteStateConfig, RemoteBackendConfig {
}
