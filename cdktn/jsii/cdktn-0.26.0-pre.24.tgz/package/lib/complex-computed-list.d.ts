import { IResolvable, IResolveContext } from "./tokens";
import { IInterpolatingParent, ITerraformAddressable } from "./terraform-addressable";
import { DynamicListTerraformIterator } from ".";
/**
 * Base class for a token that references a complex Terraform attribute and resolves to its interpolated address.
 */
declare abstract class ComplexResolvable implements IResolvable, ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    readonly creationStack: string[];
    /**
     * @internal
     */
    protected _fqn?: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    abstract computeFqn(): string;
    get fqn(): string;
    resolve(_context: IResolveContext): any;
    toString(): string;
}
/**
 * Base class for a reference to a complex Terraform attribute whose nested attributes are read as typed tokens.
 */
declare abstract class ComplexComputedAttribute extends ComplexResolvable implements IInterpolatingParent {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    getStringAttribute(terraformAttribute: string): string;
    getNumberAttribute(terraformAttribute: string): number;
    getListAttribute(terraformAttribute: string): string[];
    getBooleanAttribute(terraformAttribute: string): IResolvable;
    getNumberListAttribute(terraformAttribute: string): number[];
    getStringMapAttribute(terraformAttribute: string): {
        [key: string]: string;
    };
    getNumberMapAttribute(terraformAttribute: string): {
        [key: string]: number;
    };
    getBooleanMapAttribute(terraformAttribute: string): {
        [key: string]: boolean;
    };
    getAnyMapAttribute(terraformAttribute: string): {
        [key: string]: any;
    };
    abstract interpolationForAttribute(terraformAttribute: string): any;
}
/**
 * Reference to a Terraform `map(string)` attribute, with each value read by key as a string token.
 */
export declare class StringMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): string;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(number)` attribute, with each value read by key as a number token.
 */
export declare class NumberMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): number;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(bool)` attribute, with each value read by key as a resolvable token.
 */
export declare class BooleanMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): IResolvable;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(any)` attribute, with each value read by key as an any-typed token.
 */
export declare class AnyMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): any;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(map(string))` attribute, with each inner map read by key as a StringMap.
 */
export declare class StringMapMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): StringMap;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(map(number))` attribute, with each inner map read by key as a NumberMap.
 */
export declare class NumberMapMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): NumberMap;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(map(bool))` attribute, with each inner map read by key as a BooleanMap.
 */
export declare class BooleanMapMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): BooleanMap;
    computeFqn(): string;
}
/**
 * Reference to a Terraform `map(map(any))` attribute, with each inner map read by key as an AnyMap.
 */
export declare class AnyMapMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    lookup(key: string): AnyMap;
    computeFqn(): string;
}
/**
 * @deprecated Going to be replaced by Array of ComplexListItem
 * and will be removed in the future
 */
export declare class ComplexComputedList extends ComplexComputedAttribute {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected complexComputedListIndex: string;
    protected wrapsSet?: boolean | undefined;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, complexComputedListIndex: string, wrapsSet?: boolean | undefined);
    interpolationForAttribute(property: string): IResolvable;
    computeFqn(): string;
}
/**
 * Base class for a reference to a Terraform list or set attribute, converting sets with `tolist()` for index access.
 * Generated provider bindings extend it for lists and sets of nested blocks.
 */
export declare abstract class ComplexList extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    computeFqn(): string;
    /**
     * Creating an iterator for this complex list.
     * The list will be converted into a map with the mapKeyAttributeName as the key.
     * @param mapKeyAttributeName
     * @returns
     */
    allWithMapKey(mapKeyAttributeName: string): DynamicListTerraformIterator;
}
/**
 * Reference to a Terraform `list(bool)` attribute, with each element read by index as a resolvable token.
 */
export declare class BooleanList extends ComplexList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): IResolvable;
}
/**
 * Reference to a Terraform `list(list(string))` attribute, with each inner list read by index as a string list.
 */
export declare class StringListList extends ComplexList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): string[];
}
/**
 * Reference to a Terraform `list(list(number))` attribute, with each inner list read by index as a number list.
 */
export declare class NumberListList extends ComplexList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): number[];
}
/**
 * Reference to a Terraform `list(list(bool))` attribute, with each inner list read by index as a resolvable token.
 */
export declare class BooleanListList extends ComplexList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): IResolvable;
}
/**
 * Reference to a Terraform `list(list(any))` attribute, with each inner list read by index as a resolvable token.
 */
export declare class AnyListList extends ComplexList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): IResolvable;
}
/**
 * Base class for a reference to a Terraform map attribute.
 * Generated provider bindings extend it for maps of nested objects and maps of lists of nested objects.
 */
export declare abstract class ComplexMap extends ComplexResolvable implements ITerraformAddressable {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    computeFqn(): string;
    interpolationForAttribute(property: string): IResolvable;
}
/**
 * Reference to a single Terraform object attribute, optionally addressed by index within a list or set.
 * Generated provider bindings extend it for the output reference of each nested block.
 */
export declare class ComplexObject extends ComplexComputedAttribute {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected complexObjectIsFromSet: boolean;
    protected complexObjectIndex?: number | string | undefined;
    /**
     * @param terraformResource
     * @param terraformAttribute
     * @param complexObjectIndex the index of the complex object in a list
     * @param complexObjectIsFromSet set to true if this item is from inside a set and needs tolist() for accessing it
     *                               set to "0" for single list items
     */
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, complexObjectIsFromSet: boolean, complexObjectIndex?: number | string | undefined);
    interpolationForAttribute(property: string): IResolvable;
    protected interpolationAsList(): IResolvable;
    computeFqn(): string;
}
/**
 * Base class for a reference to a Terraform list or set of maps, converting sets with `tolist()` for index access.
 * Generated provider bindings extend it for lists of maps and lists of lists of nested objects.
 */
export declare abstract class MapList extends ComplexResolvable implements ITerraformAddressable, IInterpolatingParent {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    computeFqn(): string;
    interpolationForAttribute(property: string): IResolvable;
}
/**
 * Reference to a Terraform `list(map(string))` attribute, with each map read by index as a StringMap.
 */
export declare class StringMapList extends MapList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): StringMap;
}
/**
 * Reference to a Terraform `list(map(number))` attribute, with each map read by index as a NumberMap.
 */
export declare class NumberMapList extends MapList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): NumberMap;
}
/**
 * Reference to a Terraform `list(map(bool))` attribute, with each map read by index as a BooleanMap.
 */
export declare class BooleanMapList extends MapList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): BooleanMap;
}
/**
 * Reference to a Terraform `list(map(any))` attribute, with each map read by index as an AnyMap.
 */
export declare class AnyMapList extends MapList {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    get(index: number): AnyMap;
}
/**
 * Reference to a Terraform `map(list(string))` attribute, with each list read by key as a string list.
 */
export declare class StringListMap extends ComplexMap {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    get(key: string): string[];
}
/**
 * Reference to a Terraform `map(list(number))` attribute, with each list read by key as a number list.
 */
export declare class NumberListMap extends ComplexMap {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    get(key: string): number[];
}
/**
 * Reference to a Terraform `map(list(bool))` attribute, with each list read by key as a resolvable token.
 */
export declare class BooleanListMap extends ComplexMap {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    get(key: string): IResolvable;
}
/**
 * Reference to a Terraform `map(list(any))` attribute, with each list read by key as a resolvable token.
 */
export declare class AnyListMap extends ComplexMap {
    protected terraformResource: IInterpolatingParent;
    protected terraformAttribute: string;
    constructor(terraformResource: IInterpolatingParent, terraformAttribute: string);
    get(key: string): IResolvable;
}
export {};
