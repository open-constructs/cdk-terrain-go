import { IResolvable } from "../tokens/resolvable";
type TFValue<T> = {
    variadic?: boolean;
    value: T;
};
type TFValueValidator<T> = (value: T) => TFValue<T>;
type ExecutableTfFunction = (...args: any[]) => IResolvable;
/**
 * Validator that accepts any value
 * @param value Value to validate
 * @returns The wrapped value
 */
export declare function anyValue<T>(value: T): TFValue<T>;
/**
 * Validator for map values; accepts any value without checking it
 * @param value Value to validate
 * @returns The wrapped value
 */
export declare function mapValue<T>(value: T): TFValue<T>;
/**
 * Validator that accepts a string or a token
 * @param value Value to validate
 * @returns The wrapped value
 * @throws If the value is neither a string nor a token, or is a string containing unescaped double quotes
 */
export declare function stringValue<T extends string>(value: T): TFValue<T>;
/**
 * Validator that accepts a number or a token
 * @param value Value to validate
 * @returns The wrapped value
 * @throws If the value is neither a number nor a token
 */
export declare function numericValue<T>(value: T): TFValue<T>;
/**
 * Creates a validator for lists whose elements are checked with the given element validator. Tokens and non-array
 * values pass through unchanged; `null`/`undefined` elements are dropped, token elements are kept as-is and plain
 * string elements are wrapped in double quotes.
 * @param type Validator applied to each non-token element
 * @returns A list validator that throws if an element fails the element validator
 */
export declare function listOf<T>(type: TFValueValidator<T>): TFValueValidator<T[]>;
/**
 * Creates a validator for a variadic argument: validates the value as a list and marks it to be expanded into
 * separate arguments of the Terraform function call
 * @param type Validator applied to each element
 * @returns A validator for the variadic argument
 */
export declare function variadic<T>(type: TFValueValidator<T>): TFValueValidator<T[]>;
/**
 * Converts a resolvable into a string token
 * @param value Resolvable to convert
 * @returns String token
 */
export declare function asString(value: IResolvable): string;
/**
 * Converts a resolvable into a number token
 * @param value Resolvable to convert
 * @returns Number token
 */
export declare function asNumber(value: IResolvable): number;
/**
 * Converts a resolvable into a string list token
 * @param value Resolvable to convert
 * @returns String list token
 */
export declare function asList(value: IResolvable): string[];
/**
 * Converts a resolvable into a string map token
 * @param value Resolvable to convert
 * @returns String map token
 */
export declare function asStringMap(value: IResolvable): {
    [key: string]: string;
};
/**
 * Returns the resolvable unchanged, as booleans can not be represented as a token
 * @param value Resolvable to return
 * @returns The same resolvable
 */
export declare function asBoolean(value: IResolvable): IResolvable;
/**
 * Converts a resolvable into a string token typed as `any`
 * @param value Resolvable to convert
 * @returns String token typed as `any`
 */
export declare function asAny(value: IResolvable): any;
/**
 * Creates a function that validates its arguments and returns a Terraform function call expression
 * @param name Name of the Terraform function
 * @param argValidators Validators for each positional argument
 * @returns A function returning the call expression; it throws if the number of arguments does not match the
 * validators or an argument fails validation
 */
export declare function terraformFunction(name: string, argValidators: TFValueValidator<any>[]): ExecutableTfFunction;
export {};
