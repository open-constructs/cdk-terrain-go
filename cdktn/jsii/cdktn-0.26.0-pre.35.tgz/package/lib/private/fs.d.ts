/**
 * Predicate deciding whether a tree entry is skipped.
 * `relPath` is always `/`-separated and relative to the walk root, so patterns
 * behave identically on Windows. `isDirectory` is supplied from the walker's
 * `lstat` so `.gitignore` / `.dockerignore`-style directory-only patterns can
 * be honored without the predicate stat-ing the path itself.
 */
export type ExcludePredicate = (relPath: string, isDirectory: boolean) => boolean;
export interface CopySyncOptions {
    /**
     * Entries for which this returns true are not copied. Called with the
     * entry's `/`-separated relative path and whether it is a directory.
     * Excluding a directory also skips everything below it, unless
     * {@link descendIntoExcludedDirectories} is set.
     *
     * @default - nothing is excluded
     */
    readonly shouldExclude?: ExcludePredicate;
    /**
     * Keep walking into an excluded directory instead of pruning it. The
     * directory entry itself is still omitted; its children are visited and
     * re-tested against {@link shouldExclude}, so a strategy with negation
     * patterns (`node_modules` + `!node_modules/keep`) can re-include entries
     * below an excluded parent. Costs a full walk of excluded subtrees, so it
     * is off unless a strategy asks for it.
     *
     * @default false
     */
    readonly descendIntoExcludedDirectories?: boolean;
}
/**
 * Copy a file or directory. The directory can have contents and subfolders.
 * Symlinks are recreated as symlinks rather than dereferenced, which keeps the
 * copy consistent with {@link hashPath} (it hashes links by their target) and
 * makes dangling links and link cycles harmless.
 * @param src - source path
 * @param dest - destination path
 * @param options - copy behaviour, see {@link CopySyncOptions}
 */
export declare function copySync(src: string, dest: string, options?: CopySyncOptions): void;
/**
 * Zips contents at src and places zip archive at dest.
 * @param src - directory to archive
 * @param dest - path to write the resulting zip to
 * @param shouldExclude - entries to omit, see {@link CopySyncOptions.shouldExclude}
 * @param descendIntoExcludedDirectories - keep walking excluded directories,
 * see {@link CopySyncOptions.descendIntoExcludedDirectories}
 * @param rejectEscapingSymlinks - reject a symlink whose target resolves
 * outside `src` and is not a portable absolute path, rather than shipping a
 * link that dangles once extracted elsewhere. Gated behind
 * `canonicalAssetHashes`: a portable absolute target (a Lambda-layer-style
 * `/opt` link) ships verbatim either way, since it means the same thing
 * wherever the archive is extracted — but a Windows drive-letter or UNC
 * target (what Windows always reports for a pnpm/npm junction) is rejected
 * just like a relative escape, since on a POSIX extractor it has no leading
 * `/` and resolves as a dangling relative path instead.
 */
export declare function archiveSync(src: string, dest: string, shouldExclude?: ExcludePredicate, descendIntoExcludedDirectories?: boolean, rejectEscapingSymlinks?: boolean): void;
export interface HashPathOptions {
    /**
     * Use the canonical entry-framed hash instead of the legacy
     * content-concatenation hash. Enabled through the `canonicalAssetHashes`
     * feature flag.
     */
    readonly canonical?: boolean;
    /**
     * Frame for an archive artifact: archiveSync never emits ZIP directory
     * entries, so canonical hashing omits directory records and the hash
     * tracks the emitted archive bytes exactly. Non-empty directories stay
     * visible through the relative paths of their contents. Has no effect on
     * the legacy scheme, which never records directories.
     */
    readonly archive?: boolean;
    /**
     * Entries for which this returns true are omitted from the digest. Excluding
     * a directory also omits everything below it, unless
     * {@link descendIntoExcludedDirectories} is set. The same predicate must be
     * given to {@link copySync} so the hash and the emitted artifact describe the
     * same set of files.
     *
     * @default - nothing is excluded
     */
    readonly shouldExclude?: ExcludePredicate;
    /**
     * Keep walking into excluded directories, see
     * {@link CopySyncOptions.descendIntoExcludedDirectories}. Must match the
     * value given to {@link copySync} / {@link archiveSync} so the digest covers
     * the same file set the artifact contains.
     *
     * @default false
     */
    readonly descendIntoExcludedDirectories?: boolean;
}
/**
 * Compute a stable MD5 hash of a file or directory's contents.
 * In both schemes symlinks are hashed by their metadata (path + target)
 * instead of being followed, so shared targets are not double-counted and
 * cycles cannot recurse; a symlink at the root itself is followed, matching
 * how the asset source path is opened when the artifact is emitted.
 * @param src - path to a file or directory to hash
 * @param options - hash scheme selection, see {@link HashPathOptions}
 * @returns uppercased hex digest, truncated to HASH_LEN characters
 */
export declare function hashPath(src: string, options?: HashPathOptions): string;
/**
 * Build a predicate matching the exclusion forms accepted by
 * `AssetHashOptions.exclude` (via `ExcludeIgnoreStrategy`): an exact relative
 * path, a `*.ext` suffix, or a directory (with or without a trailing `/`),
 * which also excludes its contents.
 * Deliberately not a full glob implementation — `**`, `?`, character classes and
 * `!` negation are not supported, and a pattern is never interpreted as
 * anchoring to a subdirectory it does not name.
 * The returned matcher looks only at the path, not at whether the entry is a
 * directory: `dir` and `dir/` both match a directory named `dir` and its
 * contents. It is therefore narrower than {@link ExcludePredicate}, which also
 * receives an `isDirectory` flag for strategies that need it.
 * @param exclude - patterns to exclude
 * @returns predicate over `/`-separated paths relative to the asset root
 */
export declare function excludeMatcher(exclude: string[]): (relativePath: string) => boolean;
/**
 * Walk upward from `rootPath` looking for a file with the given name.
 * Returns the absolute path of the first match, or `null` if the search
 * reaches the filesystem root without finding it.
 * @param file - filename to search for
 * @param rootPath - directory to start the search from (defaults to cwd)
 * @returns absolute path to the file, or null if not found
 */
export declare function findFileAboveCwd(file: string, rootPath?: string): string | null;
/**
 * Rename `src` to `dest`, retrying with a short backoff while Windows refuses
 * because a file inside is briefly open (antivirus, search indexer).
 * @param src - path to rename
 * @param dest - new path
 */
export declare function renameSyncWithRetry(src: string, dest: string): void;
/**
 * Remove `target` recursively, letting Node retry while Windows briefly holds
 * a file inside open.
 * @param target - path to remove
 */
export declare function rmSyncWithRetry(target: string): void;
/**
 * Repoint a win32 junction fallback (see `copySync`'s `createLink`) that was
 * created under `oldRoot` and then moved, folder and all, to `newRoot`.
 *
 * A junction stores an absolute target. `copySync` points that target at the
 * copy it is building (`oldRoot`) so the result is self-contained, but a
 * caller that stages into a sibling folder and renames it into place (so a
 * failed build never leaves a reusable folder) moves the junction without
 * moving the text inside it. This walks `newRoot` and rewrites any junction
 * whose target still points under `oldRoot` to the same relative location
 * under `newRoot` instead.
 * @param newRoot - the folder's path after the move
 * @param oldRoot - the folder's path before the move, as baked into any
 * junction `copySync` created inside it
 */
export declare function reanchorJunctions(newRoot: string, oldRoot: string): void;
