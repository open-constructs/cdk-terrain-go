import { IValidation } from "constructs";
export type TerraformCliName = "terraform" | "opentofu" | "unknown";
export interface TerraformCliVersion {
    readonly name: TerraformCliName;
    readonly version?: string;
}
export interface TerraformFeatureVersionConstraints {
    readonly terraform?: string;
    readonly opentofu?: string;
}
/**
 * Parses the output of `terraform version` or `tofu version`.
 *
 * Plain text version output is used because both Terraform and OpenTofu expose
 * a Terraform-compatible `terraform_version` key in `version -json` output.
 */
export declare function parseTerraformCliVersion(versionOutput: string): TerraformCliVersion;
/**
 * Validates whether the selected Terraform-compatible CLI supports a feature.
 *
 * A feature can become available in Terraform and OpenTofu at different
 * versions, so the validation matrix is feature -> CLI product -> semver range.
 */
export declare class ValidateTerraformFeatureVersion implements IValidation {
    protected featureName: string;
    protected constraints: TerraformFeatureVersionConstraints;
    protected versionCommand: string;
    protected binary: string;
    protected hint?: string | undefined;
    constructor(featureName: string, constraints: TerraformFeatureVersionConstraints, versionCommand?: string, binary?: string, hint?: string | undefined);
    validate(): string[];
}
