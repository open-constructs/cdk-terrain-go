import { Construct } from "constructs";
export declare function resolve<T>(scope: Construct, obj: T, preparing?: boolean): T;
