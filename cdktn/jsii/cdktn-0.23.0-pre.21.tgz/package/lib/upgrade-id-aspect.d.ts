import { IAspect } from "./aspect";
import { IConstruct } from "constructs";
/**
 * For migrating past 0.17 where the feature flag for the old id generation logic was removed after being deprecated since 0.15
 */
export declare class MigrateIds implements IAspect {
    visit(node: IConstruct): void;
}
