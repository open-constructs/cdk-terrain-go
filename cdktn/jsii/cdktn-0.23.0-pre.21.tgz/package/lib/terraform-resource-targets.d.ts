/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { TerraformResource } from "./terraform-resource";
/**
 *
 */
export declare class TerraformResourceTargets {
    private _resourceTargetMap;
    private prettyPrintEntries;
    addResourceTarget(resource: TerraformResource, target: string): void;
    getResourceByTarget(target: string): TerraformResource;
}
