/**
 * Iterator for the Terraform count property
 */
export declare class TerraformCount {
    private readonly count;
    static of(count: number): TerraformCount;
    static isTerraformCount(x: any): x is TerraformCount;
    private constructor();
    get index(): number;
    toTerraform(): number;
    toString(): string;
}
