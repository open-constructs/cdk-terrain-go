/**
 * fails early if the environment contains e.g. invalid version combinations
 */
export declare function validateEnvironment(): void;
