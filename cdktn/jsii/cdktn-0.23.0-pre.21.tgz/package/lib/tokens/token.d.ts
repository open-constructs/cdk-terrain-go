import { IConstruct } from "constructs";
import { IResolvable, ITokenResolver } from "./resolvable";
import { TokenizedStringFragments } from "./string-fragments";
/**
 * Represents a special or lazily-evaluated value.
 *
 * Can be used to delay evaluation of a certain value in case, for example,
 * that it requires some context or late-bound data. Can also be used to
 * mark values that need special processing at document rendering time.
 *
 * Tokens can be embedded into strings while retaining their original
 * semantics.
 */
export declare class Token {
    /**
     * Returns true if obj represents an unresolved value
     *
     * One of these must be true:
     *
     * - `obj` is an IResolvable
     * - `obj` is a string containing at least one encoded `IResolvable`
     * - `obj` is either an encoded number or list
     *
     * This does NOT recurse into lists or objects to see if they
     * containing resolvables.
     *
     * @param obj The object to test.
     */
    static isUnresolved(obj: any): boolean;
    /**
     * Return a reversible string representation of this token
     *
     * If the Token is initialized with a literal, the stringified value of the
     * literal is returned. Otherwise, a special quoted string representation
     * of the Token is returned that can be embedded into other strings.
     *
     * Strings with quoted Tokens in them can be restored back into
     * complex values with the Tokens restored by calling `resolve()`
     * on the string.
     */
    static asString(value: any, options?: EncodingOptions): string;
    /**
     * Return a reversible number representation of this token
     */
    static asNumber(value: any): number;
    /**
     * Return a reversible list representation of this token
     */
    static asList(value: any, options?: EncodingOptions): string[];
    /**
     * Return a reversible list representation of this token
     */
    static asNumberList(value: any): number[];
    /**
     * Return a reversible map representation of this token
     */
    static asMap(value: any, mapValue: any, options?: EncodingOptions): {
        [key: string]: any;
    };
    /**
     * String Map token value representation
     */
    static readonly STRING_MAP_TOKEN_VALUE = "String Map Token Value";
    /**
     * Return a reversible map representation of this token
     */
    static asStringMap(value: any, options?: EncodingOptions): {
        [key: string]: string;
    };
    /**
     * Number Map token value representation
     */
    static readonly NUMBER_MAP_TOKEN_VALUE = -123456789;
    /**
     * Return a reversible map representation of this token
     */
    static asNumberMap(value: any, options?: EncodingOptions): {
        [key: string]: number;
    };
    /**
     * Return a reversible map representation of this token
     */
    static asBooleanMap(value: any, options?: EncodingOptions): {
        [key: string]: boolean;
    };
    /**
     * Any map token representation
     */
    static readonly ANY_MAP_TOKEN_VALUE = "Any Map Token Value";
    /**
     * Return a reversible map representation of this token
     */
    static asAnyMap(value: any, options?: EncodingOptions): {
        [key: string]: any;
    };
    /**
     * Return a resolvable representation of the given value
     */
    static asAny(value: any): IResolvable;
    /**
     * Return a Token containing a `null` value
     *
     * Note: This is different than `undefined`, `nil`, `None` or similar
     * as it will end up in the Terraform config and can be used to explicitly
     * not set an attribute (which is sometimes required by Terraform providers)
     *
     * @returns a Token resolving to `null` as understood by Terraform
     */
    static nullValue(): IResolvable;
}
/**
 * Less oft-needed functions to manipulate Tokens
 */
export declare class Tokenization {
    /**
     * Reverse any value into Resolvables, if possible
     */
    static reverse(x: any): IResolvable[];
    /**
     * Un-encode a string potentially containing encoded tokens
     */
    static reverseString(s: string): TokenizedStringFragments;
    /**
     * Un-encode a Tokenized value from a number
     */
    static reverseNumber(n: number): IResolvable | undefined;
    /**
     * Un-encode a Tokenized value from a list
     */
    static reverseList(l: string[]): IResolvable | undefined;
    /**
     * Un-encode a Tokenized value from a list
     */
    static reverseNumberList(l: number[]): IResolvable | undefined;
    /**
     * Un-encode a Tokenized value from a map
     */
    static reverseMap(m: {
        [key: string]: any;
    }): IResolvable | undefined;
    /**
     * Resolves an object by evaluating all tokens and removing any undefined or empty objects or arrays.
     * Values can only be primitives, arrays or tokens. Other objects (i.e. with methods) will be rejected.
     *
     * @param obj The object to resolve.
     * @param options Prefix key path components for diagnostics.
     */
    static resolve(obj: any, options: ResolveOptions): any;
    /**
     * Return whether the given object is an IResolvable object
     *
     * This is different from Token.isUnresolved() which will also check for
     * encoded Tokens, whereas this method will only do a type check on the given
     * object.
     */
    static isResolvable(obj: any): obj is IResolvable;
    /**
     * Stringify a number directly or lazily if it's a Token. If it is an object (i.e., { Ref: 'SomeLogicalId' }), return it as-is.
     */
    static stringifyNumber(x: number): string;
}
/**
 * Options to the resolve() operation
 *
 * NOT the same as the ResolveContext; ResolveContext is exposed to Token
 * implementors and resolution hooks, whereas this struct is just to bundle
 * a number of things that would otherwise be arguments to resolve() in a
 * readable way.
 */
export interface ResolveOptions {
    /**
     * The scope from which resolution is performed
     */
    readonly scope: IConstruct;
    /**
     * The resolver to apply to any resolvable tokens found
     */
    readonly resolver: ITokenResolver;
    /**
     * Whether the resolution is being executed during the prepare phase or not.
     * @default false
     */
    readonly preparing?: boolean;
}
/**
 * Properties to string encodings
 */
export interface EncodingOptions {
    /**
     * A hint for the Token's purpose when stringifying it
     * @default - no display hint
     */
    readonly displayHint?: string;
}
