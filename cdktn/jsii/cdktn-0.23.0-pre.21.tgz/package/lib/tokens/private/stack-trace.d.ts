/**
 * Captures a complete stack trace at the point of invocation.
 */
export declare function captureStackTrace(below?: Function): string[];
