/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { ValidateBinaryVersion } from "./validate-binary-version";
/**
 * Validates the existence of a Terraform binary and with a certain version or higher.
 */
export declare class ValidateTerraformVersion extends ValidateBinaryVersion {
    protected versionConstraint: string;
    protected hint?: string | undefined;
    constructor(versionConstraint: string, hint?: string | undefined);
}
