/**
 * Copy a file or directory. The directory can have contents and subfolders.
 * @param {string} src
 * @param {string} dest
 */
export declare function copySync(src: string, dest: string): void;
/**
 * Zips contents at src and places zip archive at dest
 * @param {string} src
 * @param {string} dest
 */
export declare function archiveSync(src: string, dest: string): void;
export declare function hashPath(src: string): string;
export declare function findFileAboveCwd(file: string, rootPath?: string): string | null;
